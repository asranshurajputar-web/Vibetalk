# VibeTalk Android Starter — Multi-speaker room UI

This Android Studio project includes a Kotlin + Jetpack Compose UI prototype:
- Home screen and sample rooms
- Editable display name
- Room with host, speakers, listeners
- Demo mic request approval/decline
- Demo host mute/remove controls

IMPORTANT: These controls only update local demo state. They do not sync across phones or transmit live audio. The app is not a working live voice service yet.

## Run
1. Extract this ZIP.
2. Open the VibeTalkStarter folder in Android Studio on a computer.
3. Let Gradle sync complete, then press Run.
4. For phone-only development, you will need a compatible cloud development/build setup; a normal Android phone does not include Android Studio.

## Next real implementation
- Add Agora RTC Voice SDK (official Android SDK docs: https://docs.agora.io/en/api-reference/sdks?product=chat)
- Request Android RECORD_AUDIO permission
- Use a backend to issue short-lived RTC tokens; never embed the App Certificate in the app.
- Use Firebase/Firestore or another backend to sync room roles and mic requests.
- Enforce host permissions server-side; UI-only role checks are not security.
