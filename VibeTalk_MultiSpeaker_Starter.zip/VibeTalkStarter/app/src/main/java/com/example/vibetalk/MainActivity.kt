package com.example.vibetalk

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF10121B)
private val Panel = Color(0xFF1D2130)
private val Purple = Color(0xFF8B5CF6)
private val Mint = Color(0xFF5EEAD4)

data class VoiceRoom(val title: String, val host: String, val listeners: Int, val tag: String)
data class Speaker(val name: String, val isHost: Boolean = false, val muted: Boolean = false)

private val demoRooms = listOf(
    VoiceRoom("Late Night Adda 🌙", "Pyaruuu", 18, "Chill"),
    VoiceRoom("Music & Antakshari 🎵", "Meera", 32, "Music"),
    VoiceRoom("Dil Se Dosti 💜", "Kabir", 11, "Friends"),
    VoiceRoom("Open Mic Corner 🎙️", "Riya", 7, "Talk")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VibeTalkApp() }
    }
}

@Composable
fun VibeTalkApp() {
    var selectedRoom by remember { mutableStateOf<VoiceRoom?>(null) }
    var profileName by remember { mutableStateOf("Pyaruuu") }

    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, secondary = Mint, background = Night, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Night) {
            if (selectedRoom == null) {
                HomeScreen(profileName, demoRooms, { selectedRoom = it }, { profileName = it })
            } else {
                RoomScreen(room = selectedRoom!!, myName = profileName, onLeave = { selectedRoom = null })
            }
        }
    }
}

@Composable
fun HomeScreen(name: String, rooms: List<VoiceRoom>, onJoin: (VoiceRoom) -> Unit, onNameChange: (String) -> Unit) {
    var showProfile by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("VibeTalk", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                Text("Your people. Your vibe.", color = Mint)
            }
            IconButton(onClick = { showProfile = true }) { Icon(Icons.Default.Person, "Profile", tint = Color.White) }
        }
        Spacer(Modifier.height(24.dp))
        Text("Hey, $name 👋", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Choose a room to enter the demo.", color = Color.LightGray)
        Spacer(Modifier.height(22.dp))
        Text("Voice rooms", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(rooms) { room -> RoomCard(room) { onJoin(room) } }
        }
    }
    if (showProfile) {
        var draft by remember { mutableStateOf(name) }
        AlertDialog(
            onDismissRequest = { showProfile = false },
            title = { Text("Your profile") },
            text = { OutlinedTextField(draft, { draft = it }, label = { Text("Display name") }, singleLine = true) },
            confirmButton = { TextButton(onClick = { if (draft.isNotBlank()) onNameChange(draft.trim()); showProfile = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { showProfile = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun RoomCard(room: VoiceRoom, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick() }, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).background(Purple.copy(alpha = .25f), CircleShape), contentAlignment = Alignment.Center) { Text("🎙️", fontSize = 22.sp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(room.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("Hosted by ${room.host}", color = Color.LightGray, fontSize = 13.sp)
                }
                Text("● LIVE", color = Mint, fontSize = 11.sp)
            }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${room.listeners} listeners", color = Color.LightGray, fontSize = 13.sp)
                Spacer(Modifier.weight(1f))
                Text(room.tag, color = Mint, fontSize = 12.sp)
                Spacer(Modifier.width(10.dp))
                Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("Join") }
            }
        }
    }
}

@Composable
fun RoomScreen(room: VoiceRoom, myName: String, onLeave: () -> Unit) {
    // UI-only demo state: it is not synced to other devices and does not transmit audio.
    var isHost by remember { mutableStateOf(myName.equals(room.host, ignoreCase = true)) }
    var isListener by remember { mutableStateOf(!myName.equals(room.host, ignoreCase = true)) }
    var requestPending by remember { mutableStateOf(false) }
    var myMicMuted by remember { mutableStateOf(true) }
    var info by remember { mutableStateOf("Joined as listener. Request the mic to speak.") }
    var speakers by remember {
        mutableStateOf(
            listOf(
                Speaker(room.host, isHost = true, muted = false),
                Speaker("Meera", muted = false),
                Speaker("Kabir", muted = true)
            )
        )
    }
    var pendingRequests by remember { mutableStateOf(listOf("Aarav")) }

    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onLeave) { Text("← Leave", color = Mint) }
            Spacer(Modifier.weight(1f))
            Text("ROOM DEMO", color = Color.LightGray, fontSize = 11.sp)
        }
        Spacer(Modifier.height(12.dp))
        Text(room.title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Host: ${room.host} • ${speakers.size} on stage", color = Color.LightGray)
        Spacer(Modifier.height(18.dp))
        Text("SPEAKERS", color = Mint, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(speakers, key = { it.name }) { speaker ->
                SpeakerRow(
                    speaker = speaker,
                    canManage = isHost && !speaker.isHost,
                    onToggleMute = {
                        speakers = speakers.map { if (it.name == speaker.name) it.copy(muted = !it.muted) else it }
                    },
                    onRemove = {
                        speakers = speakers.filterNot { it.name == speaker.name }
                        info = "${speaker.name} removed from stage (demo)."
                    }
                )
            }
            item {
                Spacer(Modifier.height(8.dp))
                Text("LISTENERS", color = Mint, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("24 listeners in this demo room", color = Color.LightGray, modifier = Modifier.padding(vertical = 8.dp))
            }
            if (isHost && pendingRequests.isNotEmpty()) {
                item {
                    Text("MIC REQUESTS", color = Mint, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    pendingRequests.forEach { person ->
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) {
                            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(person, color = Color.White, modifier = Modifier.weight(1f))
                                TextButton(onClick = {
                                    if (speakers.none { it.name == person }) speakers = speakers + Speaker(person, muted = true)
                                    pendingRequests = pendingRequests - person
                                    info = "$person approved as speaker (demo)."
                                }) { Text("Approve") }
                                TextButton(onClick = { pendingRequests = pendingRequests - person }) { Text("Decline") }
                            }
                        }
                    }
                }
            }
        }
        Text(info, color = Color.LightGray, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        if (isHost) {
            Button(
                onClick = {
                    pendingRequests = (pendingRequests + listOf("Riya", "Dev")).distinct()
                    info = "New demo mic requests received."
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Purple)
            ) { Text("Simulate mic requests") }
        } else if (isListener) {
            Button(
                onClick = {
                    requestPending = !requestPending
                    info = if (requestPending) "Mic request sent (demo)." else "Mic request cancelled (demo)."
                    if (requestPending && myName !in pendingRequests) pendingRequests = pendingRequests + myName
                    if (!requestPending) pendingRequests = pendingRequests - myName
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Purple)
            ) { Text(if (requestPending) "Cancel mic request" else "Request to speak") }
            Text("You are a listener. Host approval is required.", color = Color.LightGray, fontSize = 12.sp)
        } else {
            FilledTonalButton(
                onClick = { myMicMuted = !myMicMuted; info = if (myMicMuted) "Your mic muted (demo)." else "Your mic unmuted (demo)." },
                modifier = Modifier.fillMaxWidth()
            ) { Icon(if (myMicMuted) Icons.Default.MicOff else Icons.Default.Mic, null); Spacer(Modifier.width(8.dp)); Text(if (myMicMuted) "Unmute mic (demo)" else "Mute mic (demo)") }
        }
        Spacer(Modifier.height(8.dp))
        Text("Prototype only: controls change this screen, not other users or live audio.", color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
fun SpeakerRow(speaker: Speaker, canManage: Boolean, onToggleMute: () -> Unit, onRemove: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(if (speaker.isHost) Purple.copy(alpha = .35f) else Color(0xFF294C59), CircleShape), contentAlignment = Alignment.Center) {
                Icon(if (speaker.muted) Icons.Default.MicOff else Icons.Default.Mic, null, tint = if (speaker.muted) Color.LightGray else Mint)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(speaker.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(if (speaker.isHost) "HOST" else if (speaker.muted) "Mic muted" else "On stage", color = Color.LightGray, fontSize = 11.sp)
            }
            if (canManage) {
                IconButton(onClick = onToggleMute) { Icon(if (speaker.muted) Icons.Default.Mic else Icons.Default.MicOff, contentDescription = "Toggle mute", tint = Mint) }
                TextButton(onClick = onRemove) { Text("Remove") }
            }
        }
    }
}
